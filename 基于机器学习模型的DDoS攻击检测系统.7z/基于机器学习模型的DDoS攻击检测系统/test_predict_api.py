import requests
import json

# 测试预测API
url = 'http://localhost:5000/api/models/predict'
data = {
    'model_type': 'xgboost',
    'features': [100, 200, 300, 400, 500, 600, 700, 800]
}
headers = {
    'Content-Type': 'application/json'
}

response = requests.post(url, data=json.dumps(data), headers=headers)
print('响应状态码:', response.status_code)
print('响应内容:', response.json())

# 测试其他模型
data_svm = {
    'model_type': 'svm',
    'features': [100, 200, 300, 400, 500, 600, 700, 800]
}
response_svm = requests.post(url, data=json.dumps(data_svm), headers=headers)
print('\nSVM模型响应:')
print('响应状态码:', response_svm.status_code)
print('响应内容:', response_svm.json())

data_rf = {
    'model_type': 'random_forest',
    'features': [100, 200, 300, 400, 500, 600, 700, 800]
}
response_rf = requests.post(url, data=json.dumps(data_rf), headers=headers)
print('\n随机森林模型响应:')
print('响应状态码:', response_rf.status_code)
print('响应内容:', response_rf.json())
