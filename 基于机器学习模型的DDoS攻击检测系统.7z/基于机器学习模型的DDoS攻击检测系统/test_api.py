import requests
import json

# 测试获取模型列表
def test_get_models():
    print("测试获取模型列表...")
    response = requests.get('http://localhost:5000/api/models')
    print(f"状态码: {response.status_code}")
    print(f"响应内容: {response.json()}")
    print()

# 测试单条预测
def test_predict():
    print("测试单条预测...")
    data = {
        "model_type": "xgboost",
        "features": [100, 0.05, 800, 1, 500, 1, 0.8, 0.9]
    }
    response = requests.post('http://localhost:5000/api/models/predict', json=data)
    print(f"状态码: {response.status_code}")
    print(f"响应内容: {response.json()}")
    print()

# 测试批量预测
def test_batch_predict():
    print("测试批量预测...")
    data = {
        "model_type": "xgboost",
        "samples": [
            [100, 0.05, 800, 1, 500, 1, 0.8, 0.9],  # 攻击数据
            [5, 0.5, 2, 3, 1, 1, 0.2, 0.1]         # 正常数据
        ]
    }
    response = requests.post('http://localhost:5000/api/models/batch_predict', json=data)
    print(f"状态码: {response.status_code}")
    print(f"响应内容: {response.json()}")
    print()

# 测试获取日志
def test_get_logs():
    print("测试获取日志...")
    response = requests.get('http://localhost:5000/api/logs')
    print(f"状态码: {response.status_code}")
    print(f"响应内容: {response.json()}")
    print()

if __name__ == "__main__":
    test_get_models()
    test_predict()
    test_batch_predict()
    test_get_logs()
