import csv
import random
import os

# 数据集配置
DATASET_SIZE = 10000  # 数据集大小
OUTPUT_FILE = 'app/datasets/train_data.csv'  # 输出文件路径

# 特征名称
FEATURE_NAMES = [
    'packet_size',       # 数据包大小
    'packet_interval',   # 数据包间隔
    'source_ip_count',   # 源IP数量
    'destination_ip_count',  # 目的IP数量
    'source_port_count', # 源端口数量
    'destination_port_count',  # 目的端口数量
    'traffic_burstiness',  # 流量突发度
    'anomaly_score'      # 异常特征
]

# 生成正常流量特征（进一步增加重叠）
def generate_normal_traffic():
    # 基础特征
    base_features = [
        random.uniform(1, 50),      # 数据包大小（大幅扩大）
        random.uniform(0, 0.5),     # 数据包间隔（大幅扩大）
        random.uniform(1, 50),      # 源IP数量（大幅扩大）
        random.uniform(1, 15),      # 目的IP数量
        random.uniform(1, 50),      # 源端口数量（大幅扩大）
        random.uniform(1, 10),      # 目的端口数量
        random.uniform(0, 0.8),     # 流量突发度（大幅扩大）
        random.uniform(0, 0.7)      # 异常特征（大幅扩大）
    ]
    
    # 10%的概率生成接近攻击的正常流量
    if random.random() < 0.1:
        return [
            random.uniform(40, 70),      # 数据包大小
            random.uniform(0, 0.2),      # 数据包间隔
            random.uniform(40, 80),      # 源IP数量
            random.uniform(1, 5),        # 目的IP数量
            random.uniform(40, 80),      # 源端口数量
            random.uniform(1, 5),        # 目的端口数量
            random.uniform(0.6, 0.9),    # 流量突发度
            random.uniform(0.6, 0.8)     # 异常特征
        ]
    
    return base_features

# 生成DDoS攻击流量特征（进一步调整阈值，增加重叠）
def generate_ddos_traffic():
    # 基础特征
    base_features = [
        random.uniform(10, 100),     # 数据包大小（大幅降低下限）
        random.uniform(0, 0.4),      # 数据包间隔（大幅提高上限）
        random.uniform(10, 1000),    # 源IP数量（大幅降低下限）
        random.uniform(1, 10),       # 目的IP数量（大幅扩大）
        random.uniform(10, 1000),    # 源端口数量（大幅降低下限）
        random.uniform(1, 10),       # 目的端口数量（大幅扩大）
        random.uniform(0.2, 1),      # 流量突发度（大幅降低下限）
        random.uniform(0.3, 1)       # 异常特征（大幅降低下限）
    ]
    
    # 10%的概率生成接近正常的攻击流量
    if random.random() < 0.1:
        return [
            random.uniform(5, 30),       # 数据包大小
            random.uniform(0.3, 0.6),    # 数据包间隔
            random.uniform(5, 30),       # 源IP数量
            random.uniform(3, 10),       # 目的IP数量
            random.uniform(5, 30),       # 源端口数量
            random.uniform(3, 10),       # 目的端口数量
            random.uniform(0.2, 0.5),    # 流量突发度
            random.uniform(0.3, 0.5)     # 异常特征
        ]
    
    return base_features

# 生成数据集
def generate_dataset():
    # 确保输出目录存在
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    
    with open(OUTPUT_FILE, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        # 写入表头
        header = FEATURE_NAMES + ['label']  # label: 0=正常, 1=攻击
        writer.writerow(header)
        
        # 生成数据
        for i in range(DATASET_SIZE):
            # 50%的概率生成攻击流量，50%生成正常流量
            if random.random() > 0.5:
                features = generate_ddos_traffic()
                label = 1  # 攻击
            else:
                features = generate_normal_traffic()
                label = 0  # 正常
            
            # 添加随机噪声
            noisy_features = []
            for feature in features:
                # 添加5%的随机噪声
                noise = feature * random.uniform(-0.05, 0.05)
                noisy_features.append(feature + noise)
            
            # 写入一行数据
            row = noisy_features + [label]
            writer.writerow(row)
            
            # 打印进度
            if (i + 1) % 1000 == 0:
                print(f'已生成 {i + 1}/{DATASET_SIZE} 条数据')

if __name__ == '__main__':
    print('开始生成改进的DDoS攻击检测训练数据集...')
    generate_dataset()
    print(f'数据集生成完成！')
    print(f'数据集大小: {DATASET_SIZE} 条记录')
    print(f'输出文件: {OUTPUT_FILE}')
    print('数据集特点：')
    print('- 增加了特征值的重叠区域')
    print('- 添加了随机噪声')
    print('- 扩大了特征值的范围')
    print('- 使模型训练更加真实')
