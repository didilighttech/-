#!/usr/bin/env python3
"""
验证prediction_logs.json文件的JSON格式是否有效
"""

import json
import os

# JSON文件路径
JSON_FILE = 'app/datasets/prediction_logs.json'

# 验证JSON文件
def validate_json():
    print(f"验证 {JSON_FILE} 文件...")
    
    try:
        # 检查文件是否存在
        if not os.path.exists(JSON_FILE):
            print(f"错误: 文件 {JSON_FILE} 不存在")
            return False
        
        # 检查文件大小
        file_size = os.path.getsize(JSON_FILE)
        print(f"文件大小: {file_size} 字节")
        
        # 读取并解析JSON
        with open(JSON_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # 验证数据结构
        if isinstance(data, list):
            print(f"JSON格式有效！")
            print(f"日志条目数量: {len(data)}")
            
            # 检查前几个条目的结构
            if len(data) > 0:
                print("\n前3个日志条目的结构:")
                for i, entry in enumerate(data[:3]):
                    print(f"\n条目 {i+1}:")
                    print(f"  时间戳: {entry.get('timestamp')}")
                    print(f"  特征: {entry.get('features')}")
                    print(f"  预测: {entry.get('prediction')}")
                    print(f"  模型类型: {entry.get('model_type')}")
                    print(f"  是否攻击: {entry.get('is_attack')}")
            
            return True
        else:
            print(f"错误: JSON数据不是列表格式")
            return False
            
    except json.JSONDecodeError as e:
        print(f"错误: JSON格式无效 - {e}")
        # 尝试定位错误位置
        try:
            with open(JSON_FILE, 'r', encoding='utf-8') as f:
                content = f.read()
            # 打印错误位置附近的内容
            error_pos = e.pos
            start = max(0, error_pos - 50)
            end = min(len(content), error_pos + 50)
            print(f"错误位置附近的内容:")
            print(f"...{content[start:end]}...")
        except:
            pass
        return False
    except Exception as e:
        print(f"错误: {e}")
        return False

if __name__ == '__main__':
    validate_json()
