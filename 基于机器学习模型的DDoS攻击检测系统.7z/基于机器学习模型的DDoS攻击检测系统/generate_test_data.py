import random
import requests
import time

class TestDataGenerator:
    def __init__(self):
        self.api_url = 'http://localhost:5000/api/models/predict'
    
    def generate_normal_traffic(self):
        """生成正常流量数据"""
        return [
            random.uniform(0, 10),      # 数据包大小
            random.uniform(0, 1),       # 数据包间隔
            random.uniform(0, 5),       # 源IP数量
            random.uniform(0, 5),       # 目的IP数量
            random.uniform(0, 2),       # 源端口数量
            random.uniform(0, 2),       # 目的端口数量
            random.uniform(0, 0.5),     # 流量突发度
            random.uniform(0, 0.3)      # 异常特征
        ]
    
    def generate_ddos_traffic(self):
        """生成DDoS攻击数据"""
        return [
            random.uniform(0, 100),     # 数据包大小（更大）
            random.uniform(0, 0.1),     # 数据包间隔（更小）
            random.uniform(50, 1000),   # 源IP数量（更多）
            random.uniform(0, 2),       # 目的IP数量（更少，集中攻击）
            random.uniform(100, 1000),  # 源端口数量（更多）
            random.uniform(0, 2),       # 目的端口数量（更少，集中攻击）
            random.uniform(0.5, 1),     # 流量突发度（更高）
            random.uniform(0.7, 1)      # 异常特征（更高）
        ]
    
    def send_prediction(self, model_type='xgboost'):
        """发送预测请求"""
        # 随机选择生成正常流量或攻击流量
        if random.random() > 0.5:
            features = self.generate_ddos_traffic()
            actual_label = 1
        else:
            features = self.generate_normal_traffic()
            actual_label = 0
        
        data = {
            'model_type': model_type,
            'features': features
        }
        
        try:
            response = requests.post(self.api_url, json=data)
            if response.status_code == 200:
                prediction = response.json()['prediction']
                return True
            else:
                print(f"请求失败: {response.status_code}")
                return False
        except Exception as e:
            print(f"发送请求时出错: {e}")
            return False

if __name__ == "__main__":
    generator = TestDataGenerator()
    print("开始生成测试数据...")
    
    # 生成50条测试数据
    success_count = 0
    total_count = 50
    
    for i in range(total_count):
        print(f"生成数据 {i+1}/{total_count}")
        if generator.send_prediction():
            success_count += 1
        # 随机间隔，模拟真实流量
        time.sleep(random.uniform(0.1, 0.5))
    
    print(f"测试数据生成完成，成功: {success_count}/{total_count}")
