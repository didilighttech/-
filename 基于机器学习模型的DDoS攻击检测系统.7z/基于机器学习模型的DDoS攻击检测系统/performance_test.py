import requests
import time
import threading
import statistics

# 测试配置
BASE_URL = 'http://localhost:5000/api/models/predict'
CONCURRENT_REQUESTS = 50
TOTAL_REQUESTS = 200

# 测试数据
test_data = {
    "model_type": "xgboost",
    "features": [100, 0.05, 800, 1, 500, 1, 0.8, 0.9]
}

# 存储响应时间
response_times = []
success_count = 0
error_count = 0

# 测试函数
def test_request():
    global success_count, error_count
    try:
        start_time = time.time()
        response = requests.post(BASE_URL, json=test_data)
        end_time = time.time()
        response_time = end_time - start_time
        response_times.append(response_time)
        
        if response.status_code == 200:
            success_count += 1
        else:
            error_count += 1
    except Exception as e:
        error_count += 1

# 并发测试
def run_concurrent_test():
    print(f"开始性能测试: {CONCURRENT_REQUESTS}个并发请求，共{TOTAL_REQUESTS}个请求")
    print("-" * 60)
    
    threads = []
    request_count = 0
    
    while request_count < TOTAL_REQUESTS:
        # 创建并发线程
        for i in range(min(CONCURRENT_REQUESTS, TOTAL_REQUESTS - request_count)):
            thread = threading.Thread(target=test_request)
            threads.append(thread)
            thread.start()
        
        # 等待所有线程完成
        for thread in threads:
            thread.join()
        
        request_count += len(threads)
        threads = []
        
        print(f"已完成 {request_count}/{TOTAL_REQUESTS} 个请求")
    
    print("-" * 60)
    print("性能测试结果:")
    print(f"总请求数: {TOTAL_REQUESTS}")
    print(f"成功请求数: {success_count}")
    print(f"错误请求数: {error_count}")
    print(f"成功率: {success_count/TOTAL_REQUESTS*100:.2f}%")
    
    if response_times:
        print(f"平均响应时间: {statistics.mean(response_times)*1000:.2f} ms")
        print(f"最大响应时间: {max(response_times)*1000:.2f} ms")
        print(f"最小响应时间: {min(response_times)*1000:.2f} ms")
        print(f"响应时间标准差: {statistics.stdev(response_times)*1000:.2f} ms")
    else:
        print("无响应时间数据")

if __name__ == "__main__":
    run_concurrent_test()
