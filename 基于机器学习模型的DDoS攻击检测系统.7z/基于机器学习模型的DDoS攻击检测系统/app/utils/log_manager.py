import json
import os
from datetime import datetime
from app import db
from app.models.user import PredictionLog

class LogManager:
    def __init__(self):
        # 初始化时不需要做任何操作，数据库表会自动创建
        pass
    
    def log_prediction(self, features, prediction, model_type):
        try:
            # 创建新日志条目
            log_entry = PredictionLog(
                features=json.dumps(features),  # 将特征值转换为JSON字符串存储
                prediction=int(prediction),
                model_type=model_type,
                is_attack=bool(prediction)
            )
            
            # 添加到数据库
            db.session.add(log_entry)
            db.session.commit()
        except Exception as e:
            print(f"Error logging prediction: {e}")
            db.session.rollback()
    
    def get_logs(self, limit=100):
        try:
            # 从数据库获取日志，按时间倒序排序
            logs = PredictionLog.query.order_by(PredictionLog.timestamp.desc()).limit(limit).all()
            
            # 转换为字典列表
            result = []
            for log in logs:
                result.append({
                    'id': log.id,
                    'timestamp': log.timestamp.isoformat(),
                    'features': json.loads(log.features),
                    'prediction': log.prediction,
                    'model_type': log.model_type,
                    'is_attack': log.is_attack
                })
            
            return result
        except Exception as e:
            print(f"Error getting logs: {e}")
            return []
    
    def get_logs_by_time_range(self, start_time, end_time):
        try:
            # 从数据库获取时间范围内的日志
            logs = PredictionLog.query.filter(
                PredictionLog.timestamp >= start_time,
                PredictionLog.timestamp <= end_time
            ).order_by(PredictionLog.timestamp.desc()).all()
            
            # 转换为字典列表
            result = []
            for log in logs:
                result.append({
                    'id': log.id,
                    'timestamp': log.timestamp.isoformat(),
                    'features': json.loads(log.features),
                    'prediction': log.prediction,
                    'model_type': log.model_type,
                    'is_attack': log.is_attack
                })
            
            return result
        except Exception as e:
            print(f"Error getting logs by time range: {e}")
            return []
    
    def get_logs_by_attack_type(self, is_attack):
        try:
            # 从数据库获取指定攻击类型的日志
            logs = PredictionLog.query.filter(
                PredictionLog.is_attack == is_attack
            ).order_by(PredictionLog.timestamp.desc()).all()
            
            # 转换为字典列表
            result = []
            for log in logs:
                result.append({
                    'id': log.id,
                    'timestamp': log.timestamp.isoformat(),
                    'features': json.loads(log.features),
                    'prediction': log.prediction,
                    'model_type': log.model_type,
                    'is_attack': log.is_attack
                })
            
            return result
        except Exception as e:
            print(f"Error getting logs by attack type: {e}")
            return []
