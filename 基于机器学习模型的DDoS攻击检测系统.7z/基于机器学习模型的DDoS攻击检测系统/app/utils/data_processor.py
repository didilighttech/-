import pandas as pd
from sklearn.model_selection import train_test_split

class DataProcessor:
    def preprocess_dataset(self, dataset_path):
        try:
            print(f"Processing dataset: {dataset_path}")
            
            # 从CSV文件读取数据
            df = pd.read_csv(dataset_path)
            
            # 提取特征和标签
            X = df.iloc[:, :-1].values  # 前8列是特征
            y = df.iloc[:, -1].values   # 最后一列是标签
            
            # 分割训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            print(f"Data processed. Training set size: {len(X_train)}, Test set size: {len(X_test)}")
            return X_train, X_test, y_train, y_test
        except Exception as e:
            print(f"Error processing dataset: {e}")
            raise
    
    def preprocess_sample(self, features):
        try:
            # 模拟特征预处理
            return features
        except Exception as e:
            print(f"Error preprocessing sample: {e}")
            raise
