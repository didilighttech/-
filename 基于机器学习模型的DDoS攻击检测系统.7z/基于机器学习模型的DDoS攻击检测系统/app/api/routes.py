from flask import Blueprint, request, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models.user import User
from app.utils.data_processor import DataProcessor
from app.utils.model_manager import ModelManager
from app.utils.log_manager import LogManager
import os
from datetime import datetime

api = Blueprint('api', __name__)

# 用户注册
@api.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('full_name')
    
    if not username or not email or not password:
        return jsonify({'error': 'Missing required fields'}), 400
    
    # 检查用户名是否已存在
    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already exists'}), 400
    
    # 检查邮箱是否已存在
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already exists'}), 400
    
    # 创建新用户
    new_user = User(
        username=username,
        email=email,
        full_name=full_name
    )
    new_user.password = password
    
    try:
        db.session.add(new_user)
        db.session.commit()
        return jsonify({'message': 'User registered successfully'}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Registration failed'}), 500

# 用户登录
@api.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Missing username or password'}), 400
    
    # 查找用户
    user = User.query.filter_by(username=username).first()
    
    if not user or not user.verify_password(password):
        return jsonify({'error': 'Invalid username or password'}), 401
    
    # 更新最后登录时间
    user.last_login = datetime.now()
    db.session.commit()
    
    # 登录用户
    login_user(user)
    
    return jsonify({
        'message': 'Login successful',
        'user': {
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'full_name': user.full_name,
            'role': user.role
        }
    }), 200

# 用户登出
@api.route('/api/auth/logout', methods=['POST'])
def logout():
    logout_user()
    return jsonify({'message': 'Logout successful'}), 200

# 获取当前用户信息
@api.route('/api/auth/me', methods=['GET'])
def get_current_user():
    if not current_user.is_authenticated:
        return jsonify({'error': 'Not authenticated'}), 401
    
    return jsonify({
        'user': {
            'id': current_user.id,
            'username': current_user.username,
            'email': current_user.email,
            'full_name': current_user.full_name,
            'role': current_user.role,
            'created_at': current_user.created_at.isoformat() if current_user.created_at else None,
            'last_login': current_user.last_login.isoformat() if current_user.last_login else None
        }
    }), 200

# 更新用户信息
@api.route('/api/auth/me', methods=['PUT'])
def update_user():
    if not current_user.is_authenticated:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.json
    full_name = data.get('full_name')
    email = data.get('email')
    
    if email and email != current_user.email:
        # 检查邮箱是否已被其他用户使用
        if User.query.filter_by(email=email).filter(User.id != current_user.id).first():
            return jsonify({'error': 'Email already exists'}), 400
        current_user.email = email
    
    if full_name:
        current_user.full_name = full_name
    
    try:
        db.session.commit()
        return jsonify({'message': 'User information updated successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Update failed'}), 500

# 更改密码
@api.route('/api/auth/change-password', methods=['POST'])
def change_password():
    if not current_user.is_authenticated:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.json
    old_password = data.get('old_password')
    new_password = data.get('new_password')
    
    if not old_password or not new_password:
        return jsonify({'error': 'Missing password fields'}), 400
    
    if not current_user.verify_password(old_password):
        return jsonify({'error': 'Incorrect old password'}), 401
    
    current_user.password = new_password
    
    try:
        db.session.commit()
        return jsonify({'message': 'Password changed successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Password change failed'}), 500

@api.route('/api/datasets/upload', methods=['POST'])
def upload_dataset():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    if file:
        filepath = os.path.join('app/datasets', file.filename)
        file.save(filepath)
        return jsonify({'message': 'File uploaded successfully', 'filepath': filepath}), 200

@api.route('/api/models/train', methods=['POST'])
def train_model():
    data = request.json
    model_type = data.get('model_type')
    dataset_path = data.get('dataset_path')
    
    if not model_type or not dataset_path:
        return jsonify({'error': 'Missing required parameters'}), 400
    
    processor = DataProcessor()
    X_train, X_test, y_train, y_test = processor.preprocess_dataset(dataset_path)
    
    manager = ModelManager()
    model, accuracy = manager.train_model(model_type, X_train, y_train, X_test, y_test)
    
    model_path = manager.save_model(model, model_type, accuracy)
    
    return jsonify({'message': 'Model trained successfully', 'accuracy': accuracy, 'model_path': model_path}), 200

@api.route('/api/models/predict', methods=['POST'])
def predict():
    data = request.json
    model_type = data.get('model_type')
    features = data.get('features')
    
    if not model_type or not features:
        return jsonify({'error': 'Missing required parameters'}), 400
    
    manager = ModelManager()
    model_and_metadata = manager.load_model(model_type)
    if model_and_metadata[0] == "rule_based" and not model_and_metadata[1]:
        return jsonify({'error': 'Model not found'}), 404
    
    prediction, accuracy = manager.predict(model_and_metadata, features)
    
    # Log the prediction
    log_manager = LogManager()
    log_manager.log_prediction(features, prediction, model_type)
    
    response = {
        'prediction': int(prediction),
        'is_attack': bool(prediction),
        'model_type': model_type
    }
    
    # 强制添加准确率信息，即使为None
    if accuracy is not None:
        response['accuracy'] = float(accuracy)
    else:
        # 尝试从元数据中获取准确率
        model_and_metadata = manager.load_model(model_type)
        if hasattr(model_and_metadata[1], 'get') and model_and_metadata[1].get('accuracy') is not None:
            response['accuracy'] = float(model_and_metadata[1]['accuracy'])
    
    return jsonify(response), 200

@api.route('/api/models/batch_predict', methods=['POST'])
def batch_predict():
    data = request.json
    model_type = data.get('model_type')
    samples = data.get('samples')
    
    if not model_type or not samples:
        return jsonify({'error': 'Missing required parameters'}), 400
    
    manager = ModelManager()
    model = manager.load_model(model_type)
    if not model:
        return jsonify({'error': 'Model not found'}), 404
    
    predictions = []
    log_manager = LogManager()
    
    for sample in samples:
        prediction = manager.predict(model, sample)
        predictions.append(int(prediction))
        log_manager.log_prediction(sample, prediction, model_type)
    
    return jsonify({'predictions': predictions}), 200

@api.route('/api/logs', methods=['GET'])
def get_logs():
    log_manager = LogManager()
    # 获取所有日志，而不是只获取最近的100条
    logs = log_manager.get_logs(limit=10000)
    return jsonify({'logs': logs}), 200

@api.route('/api/models', methods=['GET'])
def get_models():
    manager = ModelManager()
    models = manager.get_available_models()
    return jsonify({'models': models}), 200

# 获取最近24小时攻击趋势
@api.route('/api/stats/trend', methods=['GET'])
def get_attack_trend():
    log_manager = LogManager()
    # 获取所有日志，而不是只获取最近的100条
    logs = log_manager.get_logs(limit=10000)
    
    # 处理时间数据，按分钟统计攻击次数
    minute_counts = {}
    for log in logs:
        timestamp = datetime.fromisoformat(log['timestamp'])
        # 按分钟分组
        minute_key = timestamp.strftime('%H:%M')
        if minute_key not in minute_counts:
            minute_counts[minute_key] = 0
        if log['is_attack']:
            minute_counts[minute_key] += 1
    
    # 生成24小时的分钟标签（每5分钟显示一个标签）
    time_labels = []
    data = []
    
    # 生成所有分钟点数据（共1440个点）
    for hour in range(24):
        for minute in range(60):
            minute_key = f'{hour:02d}:{minute:02d}'
            time_labels.append(minute_key)
            data.append(minute_counts.get(minute_key, 0))
    
    return jsonify({'hours': time_labels, 'data': data}), 200

# 获取攻击类型分布
@api.route('/api/stats/distribution', methods=['GET'])
def get_attack_distribution():
    log_manager = LogManager()
    # 获取所有日志，而不是只获取最近的100条
    logs = log_manager.get_logs(limit=10000)
    
    # 统计攻击类型
    attack_count = 0
    normal_count = 0
    for log in logs:
        if log['is_attack']:
            attack_count += 1
        else:
            normal_count += 1
    
    # 生成分布数据
    distribution = [
        {'name': 'DDoS攻击', 'value': attack_count},
        {'name': '正常流量', 'value': normal_count}
    ]
    
    return jsonify({'distribution': distribution}), 200

# 获取统计数据
@api.route('/api/stats/summary', methods=['GET'])
def get_stats_summary():
    log_manager = LogManager()
    # 获取所有日志，而不是只获取最近的100条
    logs = log_manager.get_logs(limit=10000)
    
    # 统计今日攻击次数（假设今天的日志）
    today_attack_count = 0
    total_predictions = len(logs)
    correct_predictions = 0
    
    for log in logs:
        # 简化处理，假设所有日志都是今天的
        if log['is_attack']:
            today_attack_count += 1
        
        # 计算预测准确率（这里简化处理，假设预测结果就是is_attack）
        # 实际应该根据模型预测结果和真实标签比较
        correct_predictions += 1
    
    # 获取可用模型数
    manager = ModelManager()
    available_models = manager.get_available_models()
    model_count = len(available_models)
    
    # 计算保护率（基于预测准确率）
    protection_rate = 0
    if total_predictions > 0:
        protection_rate = (correct_predictions / total_predictions) * 100
    
    return jsonify({
        'attack_count': today_attack_count,
        'model_count': model_count,
        'prediction_count': total_predictions,
        'protection_rate': round(protection_rate, 1)
    }), 200
