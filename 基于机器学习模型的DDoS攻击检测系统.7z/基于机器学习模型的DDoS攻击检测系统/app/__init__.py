from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

app = Flask(__name__)
# 配置CORS，允许所有来源，支持凭证，允许所有方法和头部
CORS(app, 
     supports_credentials=True,
     origins=['http://localhost:8000', 'http://localhost:8080'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
     allow_headers=['Content-Type', 'Authorization'])


# 配置SQLite数据库
import os
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your-secret-key-here'

# 确保数据库文件目录存在
db_dir = os.path.dirname('database.db')
if db_dir and not os.path.exists(db_dir):
    os.makedirs(db_dir)

# 初始化数据库
db = SQLAlchemy(app)

# 初始化登录管理器
login_manager = LoginManager(app)
login_manager.login_view = 'api.login'

from app.api import routes
app.register_blueprint(routes.api)

# 导入用户模型
from app.models.user import User

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# 创建数据库表
with app.app_context():
    db.create_all()
