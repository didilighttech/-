#!/usr/bin/env python3
"""
测试真正的模型训练和预测功能
"""

from app.utils.model_manager import ModelManager
from app.utils.data_processor import DataProcessor

# 测试模型训练
def test_model_training():
    print("\n=== 测试模型训练 ===")
    
    try:
        # 使用生成的训练数据集
        dataset_path = 'app/datasets/train_data.csv'
        
        # 测试训练不同类型的模型
        model_types = ['svm', 'random_forest', 'xgboost']
        
        for model_type in model_types:
            print(f"\n训练 {model_type} 模型...")
            
            # 初始化处理器和管理器
            processor = DataProcessor()
            manager = ModelManager()
            
            # 预处理数据
            X_train, X_test, y_train, y_test = processor.preprocess_dataset(dataset_path)
            
            # 训练模型
            model, accuracy = manager.train_model(model_type, X_train, y_train, X_test, y_test)
            
            # 保存模型
            model_path = manager.save_model(model, model_type, accuracy)
            
            print(f"{model_type} 模型训练完成！")
            print(f"准确率: {accuracy:.4f}")
            print(f"模型保存路径: {model_path}")
            
    except Exception as e:
        print(f"测试模型训练失败: {e}")

# 测试模型预测
def test_model_prediction():
    print("\n=== 测试模型预测 ===")
    
    try:
        # 初始化管理器
        manager = ModelManager()
        
        # 测试数据（正常流量）
        normal_features = [5, 0.7, 3, 2, 1, 1, 0.3, 0.1]
        
        # 测试数据（攻击流量）
        attack_features = [75, 0.05, 500, 1, 500, 1, 0.8, 0.9]
        
        # 测试不同类型的模型
        model_types = ['svm', 'random_forest', 'xgboost']
        
        for model_type in model_types:
            print(f"\n测试 {model_type} 模型预测...")
            
            # 加载模型
            model = manager.load_model(model_type)
            
            if model:
                # 测试正常流量预测
                normal_prediction = manager.predict(model, normal_features)
                print(f"正常流量预测结果: {normal_prediction} (0=正常, 1=攻击)")
                
                # 测试攻击流量预测
                attack_prediction = manager.predict(model, attack_features)
                print(f"攻击流量预测结果: {attack_prediction} (0=正常, 1=攻击)")
            else:
                print(f"无法加载 {model_type} 模型")
                
    except Exception as e:
        print(f"测试模型预测失败: {e}")

if __name__ == '__main__':
    print("开始测试真正的模型训练和预测功能...")
    
    # 测试模型训练
    test_model_training()
    
    # 测试模型预测
    test_model_prediction()
    
    print("\n测试完成！")
