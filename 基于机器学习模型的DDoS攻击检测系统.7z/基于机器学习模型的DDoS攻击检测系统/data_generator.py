import random
import requests
import time
import json

class DataGenerator:
    def __init__(self):
        self.api_url = 'http://localhost:5000/api/models/predict'
        self.batch_api_url = 'http://localhost:5000/api/models/batch_predict'
    
    def generate_normal_traffic(self):
        """生成正常流量数据"""
        return [
            random.uniform(0, 10),      # 数据包大小
            random.uniform(0, 1),       # 数据包间隔
            random.uniform(0, 5),       # 源IP数量
            random.uniform(0, 5),       # 目的IP数量
            random.uniform(0, 2),       # 源端口数量
            random.uniform(0, 2),       # 目的端口数量
            random.uniform(0, 0.5),     # 流量突发度
            random.uniform(0, 0.3)      # 异常特征
        ]
    
    def generate_ddos_traffic(self):
        """生成DDoS攻击数据"""
        return [
            random.uniform(0, 100),     # 数据包大小（更大）
            random.uniform(0, 0.1),     # 数据包间隔（更小）
            random.uniform(50, 1000),   # 源IP数量（更多）
            random.uniform(0, 2),       # 目的IP数量（更少，集中攻击）
            random.uniform(100, 1000),  # 源端口数量（更多）
            random.uniform(0, 2),       # 目的端口数量（更少，集中攻击）
            random.uniform(0.5, 1),     # 流量突发度（更高）
            random.uniform(0.7, 1)      # 异常特征（更高）
        ]
    
    def send_single_prediction(self, model_type='xgboost'):
        """发送单条预测请求"""
        # 随机选择生成正常流量或攻击流量
        if random.random() > 0.5:
            features = self.generate_ddos_traffic()
            actual_label = 1
        else:
            features = self.generate_normal_traffic()
            actual_label = 0
        
        data = {
            'model_type': model_type,
            'features': features
        }
        
        try:
            response = requests.post(self.api_url, json=data)
            if response.status_code == 200:
                prediction = response.json()['prediction']
                print(f"发送数据: {features}")
                print(f"实际标签: {actual_label}, 预测结果: {prediction}")
                print(f"预测{'正确' if prediction == actual_label else '错误'}")
                print("-" * 50)
                return prediction == actual_label
            else:
                print(f"请求失败: {response.status_code}")
                return False
        except Exception as e:
            print(f"发送请求时出错: {e}")
            return False
    
    def send_batch_prediction(self, batch_size=10, model_type='xgboost'):
        """发送批量预测请求"""
        samples = []
        actual_labels = []
        
        for _ in range(batch_size):
            if random.random() > 0.5:
                features = self.generate_ddos_traffic()
                actual_labels.append(1)
            else:
                features = self.generate_normal_traffic()
                actual_labels.append(0)
            samples.append(features)
        
        data = {
            'model_type': model_type,
            'samples': samples
        }
        
        try:
            response = requests.post(self.batch_api_url, json=data)
            if response.status_code == 200:
                predictions = response.json()['predictions']
                print(f"批量发送 {batch_size} 条数据")
                correct_count = 0
                for i in range(batch_size):
                    actual = actual_labels[i]
                    pred = predictions[i]
                    if actual == pred:
                        correct_count += 1
                    print(f"样本 {i+1}: 实际={actual}, 预测={pred} {'✓' if actual == pred else '✗'}")
                accuracy = correct_count / batch_size
                print(f"批量预测准确率: {accuracy:.2f}")
                print("-" * 50)
                return accuracy
            else:
                print(f"请求失败: {response.status_code}")
                return 0
        except Exception as e:
            print(f"发送请求时出错: {e}")
            return 0
    
    def run_continuous_test(self, duration=60, interval=1, model_type='xgboost'):
        """持续测试，模拟实时流量"""
        print(f"开始持续测试，持续时间: {duration}秒，间隔: {interval}秒")
        print("-" * 50)
        
        start_time = time.time()
        correct_count = 0
        total_count = 0
        
        while time.time() - start_time < duration:
            success = self.send_single_prediction(model_type)
            if success:
                correct_count += 1
            total_count += 1
            time.sleep(interval)
        
        if total_count > 0:
            accuracy = correct_count / total_count
            print(f"测试完成，总请求数: {total_count}, 正确数: {correct_count}, 准确率: {accuracy:.2f}")
        else:
            print("测试完成，无请求发送")
    
    def run_batch_test(self, batch_count=10, batch_size=10, model_type='xgboost'):
        """批量测试"""
        print(f"开始批量测试，批次: {batch_count}, 每批大小: {batch_size}")
        print("-" * 50)
        
        total_accuracy = 0
        for i in range(batch_count):
            print(f"批次 {i+1}/{batch_count}")
            accuracy = self.send_batch_prediction(batch_size, model_type)
            total_accuracy += accuracy
            time.sleep(2)  # 间隔2秒
        
        average_accuracy = total_accuracy / batch_count
        print(f"批量测试完成，平均准确率: {average_accuracy:.2f}")

if __name__ == "__main__":
    generator = DataGenerator()
    
    # 选择测试模式
    print("请选择测试模式:")
    print("1. 单条数据测试")
    print("2. 批量数据测试")
    print("3. 持续实时测试")
    
    choice = input("请输入选择 (1/2/3): ")
    
    # 选择模型
    model_choice = input("请选择模型 (svm/random_forest/xgboost, 默认xgboost): ") or 'xgboost'
    
    if choice == '1':
        # 单条数据测试
        count = int(input("请输入测试次数: "))
        correct = 0
        for i in range(count):
            print(f"测试 {i+1}/{count}")
            if generator.send_single_prediction(model_choice):
                correct += 1
        print(f"测试完成，准确率: {correct/count:.2f}")
    
    elif choice == '2':
        # 批量数据测试
        batch_count = int(input("请输入批次数: "))
        batch_size = int(input("请输入每批大小: "))
        generator.run_batch_test(batch_count, batch_size, model_choice)
    
    elif choice == '3':
        # 持续实时测试
        duration = int(input("请输入测试持续时间 (秒): "))
        interval = float(input("请输入请求间隔 (秒): "))
        generator.run_continuous_test(duration, interval, model_choice)
    
    else:
        print("无效选择")
