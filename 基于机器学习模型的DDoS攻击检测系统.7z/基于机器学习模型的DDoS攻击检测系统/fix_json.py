#!/usr/bin/env python3
"""
修复损坏的prediction_logs.json文件
"""

import json
import os

# JSON文件路径
JSON_FILE = 'app/datasets/prediction_logs.json'

# 修复JSON文件
def fix_json():
    print(f"修复 {JSON_FILE} 文件...")
    
    try:
        # 检查文件是否存在
        if not os.path.exists(JSON_FILE):
            print(f"错误: 文件 {JSON_FILE} 不存在")
            # 创建新的空JSON文件
            with open(JSON_FILE, 'w') as f:
                json.dump([], f)
            print("已创建新的空JSON文件")
            return True
        
        # 读取文件内容
        with open(JSON_FILE, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        print(f"原始文件大小: {len(content)} 字符")
        
        # 尝试修复JSON格式
        # 方法1: 尝试找到有效的JSON结束位置
        fixed_content = content
        
        try:
            # 尝试直接解析
            data = json.loads(content)
            print("JSON文件已经是有效的，无需修复")
            return True
        except json.JSONDecodeError:
            # 尝试修复：删除末尾的多余字符
            print("尝试修复JSON格式...")
            
            # 方法2: 找到最后一个有效的 } 和 ]
            # 找到最后一个 }
            last_brace = content.rfind('}')
            if last_brace != -1:
                # 找到最后一个 ]
                last_bracket = content.rfind(']')
                if last_bracket != -1 and last_bracket > last_brace:
                    # 截取到最后一个 ]
                    fixed_content = content[:last_bracket+1]
                    print("已修复：截取到最后一个 ]，新长度: " + str(len(fixed_content)) + " 字符")
                else:
                    # 截取到最后一个 }
                    fixed_content = content[:last_brace+1]
                    # 确保是列表格式
                    if not fixed_content.startswith('['):
                        fixed_content = '[' + fixed_content + ']'
                    print("已修复：截取到最后一个 } 并添加列表包装，新长度: " + str(len(fixed_content)) + " 字符")
            else:
                # 如果无法修复，创建空列表
                fixed_content = '[]'
                print("已修复：创建空列表")
        
        # 验证修复后的内容
        try:
            data = json.loads(fixed_content)
            print("修复成功！JSON格式有效")
            print(f"修复后的数据类型: {type(data)}")
            if isinstance(data, list):
                print(f"日志条目数量: {len(data)}")
        except json.JSONDecodeError as e:
            print(f"修复失败: {e}")
            # 如果修复失败，创建空列表
            fixed_content = '[]'
            print("已创建空列表作为替代")
        
        # 写入修复后的内容
        with open(JSON_FILE, 'w', encoding='utf-8') as f:
            f.write(fixed_content)
        
        print(f"修复完成！文件已保存")
        return True
        
    except Exception as e:
        print(f"修复过程中发生错误: {e}")
        # 尝试创建新的空JSON文件
        try:
            with open(JSON_FILE, 'w') as f:
                json.dump([], f)
            print("已创建新的空JSON文件")
            return True
        except:
            print("无法创建新的JSON文件")
            return False

# 验证修复结果
def validate_fix():
    print("\n验证修复结果...")
    try:
        with open(JSON_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        print("验证成功！JSON格式有效")
        print(f"数据类型: {type(data)}")
        if isinstance(data, list):
            print(f"日志条目数量: {len(data)}")
        return True
    except Exception as e:
        print(f"验证失败: {e}")
        return False

if __name__ == '__main__':
    fix_json()
    validate_fix()
